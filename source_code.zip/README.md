## 모델 description 
 - 구축계획서 등에 명기된 간략한 모델 설명

## 모델 아키텍쳐
 - CNN 백본, Transformer 백본 등 구축계획서 명기된 간략한 모델 아키텍쳐 설명과 도식도

## input
 - input 되는 요소와 데이터 차원 등

## output
 - output 되는 요소와 데이터 차원 등

## task
 - 객체 인식 고도화 모델

## training dataset
 - traing 대상이 되는 데이터

## training 요소들
 - 사용된 loss function, optimizer 등 간략한 설명, epoch, learning rate, batch size 등 최종 하이퍼파라미터 값 기재

## evaluation metric
 - 성능 Plot 이나 Accuracy 등 기본적인 모델 성능 지표 및 수치, 유효성 검증 목표 지표와 달성 수치 기재

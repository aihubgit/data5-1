import argparse
import json
import glob

from tqdm import tqdm

def annotationsMap(annotation, index):
    annotation["image_id"] = index
    
    return annotation

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='coco Json Merge')
    parser.add_argument('--path', metavar='path', type=str, help='Json Folder Path')
    
    args = parser.parse_args()
    
    read_files = glob.glob(f'{args.path}/**/*.json', recursive=True)
    output_list = []

    jsons = []

    result = {
        "info": {},
        "images": [],
        "annotations": [],
        "categories": [],
        "licenses": []
    }
    
    with tqdm(total=len(read_files), desc='LoadAndMerge') as pbar:
        for index, f in enumerate(read_files):
            with open(f, "r") as file:
                data = json.load(file)
                data["annotations"] = list(map(lambda x: annotationsMap(x, index), data["annotations"]))
                data["images"][0]["id"] = index
                
                result["info"] = data["info"]
                result["annotations"].extend(data["annotations"])
                result["images"].extend(data["images"])
                result["categories"].extend(data["categories"])
                result["licenses"] = data["licenses"]
                
                pbar.update()

    with tqdm(total=len(result["annotations"]), desc='annotations indexing') as pbar:
        for index, annotation in enumerate(result["annotations"]):
            annotation["id"] = index
            result["annotations"][index] = annotation
            
            pbar.update()
        
    result["categories"] = list({category["id"]: category for category in result["categories"]}.values())
    
    
    with open("merged_file.json", "w") as outfile:
        json.dump(result, outfile)

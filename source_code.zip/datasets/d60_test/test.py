import splitfolders

splitfolders.ratio('./train', output="./out", seed=150, ratio=(0.8,0.1,0.1), group_prefix=2)

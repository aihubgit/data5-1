from pathlib import Path
from tqdm import tqdm

import shutil

imagePath = Path('C:/Users/dis/Downloads/51output/images')
jsonPath = Path('C:/Users/dis/Downloads/51output/jsons')
output = Path('C:/Users/dis/Downloads/51output2')

def makePath(target: Path):
    if not target.exists():
        target.mkdir(parents=True, exist_ok=True)
            
    return target

class Dataset:
    def __init__(self, train=8, val=1, test=1):
        self.ratio = {
            "train": train,
            "val": val,
            "test": test
        }
        
        self.indexs = {}
        self.files ={
            "train": [],
            "val": [],
            "test": [],
        }
    
    def getPath(self, name, basePath: Path):
        p, codeA, codeB, codeC, codeD, outher = name.split('_')
        
        key = f'{codeA}{codeB}{codeC}{codeD}'
        
        
        if key in self.indexs:
            index = self.indexs[key]
            
            index = index % (self.ratio['train'] + self.ratio['val'] + self.ratio['test'])
            
            if index < self.ratio['train']:
                path = makePath(basePath / 'Train' / codeA / codeB / codeC / codeD) / name
                
            elif index < self.ratio['train'] + self.ratio['val']:
                path = makePath(basePath / 'Val' / codeA / codeB / codeC / codeD) / name
                
            elif index < self.ratio['train'] + self.ratio['val'] + self.ratio['test']:
                path = makePath(basePath / 'Test' / codeA / codeB / codeC / codeD) / name

            
            self.indexs[key] = self.indexs[key] + 1
            return path

        self.indexs[key] = 1
        
        return makePath(basePath / 'Train' / codeA / codeB / codeC / codeD) / name
    
if __name__ == '__main__':
    imageList = list(imagePath.glob('**/*.jpg'))
    
    imageList = {x.name: x for x in imageList}
    
    jsonList = list(jsonPath.glob('**/*.json'))
    
    importance = {}
    
    dataset = Dataset()

    with tqdm(total=len(imageList), desc="dataset") as p:
        for item in jsonList:
            key = f"{item.name.split('.')[0]}.jpg"
            if key in imageList:
                image = imageList[f"{item.name.split('.')[0]}.jpg"]
                imagePath = dataset.getPath(image.name, output / 'images')
                
                parts = imagePath.parent.parts[-5:]
                
                jsonPath = makePath(output / 'jsons' / parts[0] / parts[1] / parts[2] / parts[3] / parts[4]) / item.name
                        
                shutil.move(image, imagePath)
                shutil.move(item, jsonPath)
            p.update()
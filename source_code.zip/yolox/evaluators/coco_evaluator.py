#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# Copyright (c) Megvii, Inc. and its affiliates.

import contextlib
import io
import itertools
import json
import tempfile
import time
from collections import ChainMap, defaultdict
from loguru import logger
from tabulate import tabulate
from tqdm import tqdm
import csv
import pandas as pd
import numpy as np

import torch

from tools.confusion import ConfusionMatrix,xywh2xyxy,process_batch,ap_per_class
from yolox.data.datasets import COCO_CLASSES
from yolox.utils import (
    gather,
    is_main_process,
    postprocess,
    synchronize,
    time_synchronized,
    xyxy2xywh
)


def per_class_AR_table(coco_eval, class_names=COCO_CLASSES, headers=["class", "AR"], colums=6):
    per_class_AR = {}
    recalls = coco_eval.eval["recall"]
    # dimension of recalls: [TxKxAxM]
    # recall has dims (iou, cls, area range, max dets)
    assert len(class_names) == recalls.shape[1]

    for idx, name in enumerate(class_names):
        recall = recalls[:, idx, 0, -1]
        recall = recall[recall > -1]
        ar = np.mean(recall) if recall.size else float("nan")
        per_class_AR[name] = float(ar * 100)

    num_cols = min(colums, len(per_class_AR) * len(headers))
    result_pair = [x for pair in per_class_AR.items() for x in pair]
    row_pair = itertools.zip_longest(*[result_pair[i::num_cols] for i in range(num_cols)])
    table_headers = headers * (num_cols // len(headers))
    table = tabulate(
        row_pair, tablefmt="pipe", floatfmt=".3f", headers=table_headers, numalign="left",
    )
    return table


def per_class_AP_table(coco_eval, class_names=COCO_CLASSES, headers=["class", "AP"], colums=6):
    per_class_AP = {}
    precisions = coco_eval.eval["precision"]
    # dimension of precisions: [TxRxKxAxM]
    # precision has dims (iou, recall, cls, area range, max dets)
    assert len(class_names) == precisions.shape[2]

    for idx, name in enumerate(class_names):
        # area range index 0: all area ranges
        # max dets index -1: typically 100 per image
        
        #change
        #precision = precisions[:, :, idx, 0, -1]
        precision = precisions[0, :, idx, 0, -1]
        precision = precision[precision > -1]
        ap = np.mean(precision) if precision.size else float("nan")
        per_class_AP[name] = float(ap * 100)

    num_cols = min(colums, len(per_class_AP) * len(headers))
    result_pair = [x for pair in per_class_AP.items() for x in pair]
    row_pair = itertools.zip_longest(*[result_pair[i::num_cols] for i in range(num_cols)])
    table_headers = headers * (num_cols // len(headers))
    table = tabulate(
        row_pair, tablefmt="pipe", floatfmt=".3f", headers=table_headers, numalign="left",
    )
    return table


class COCOEvaluator:
    """
    COCO AP Evaluation class.  All the data in the val2017 dataset are processed
    and evaluated by COCO API.
    """

    def __init__(
        self,
        dataloader,
        img_size: int,
        confthre: float,
        nmsthre: float,
        num_classes: int,
        testdev: bool = False,
        per_class_AP: bool = False,
        per_class_AR: bool = False,
    ):
        """
        Args:
            dataloader (Dataloader): evaluate dataloader.
            img_size: image size after preprocess. images are resized
                to squares whose shape is (img_size, img_size).
            confthre: confidence threshold ranging from 0 to 1, which
                is defined in the config file.
            nmsthre: IoU threshold of non-max supression ranging from 0 to 1.
            per_class_AP: Show per class AP during evalution or not. Default to False.
            per_class_AR: Show per class AR during evalution or not. Default to False.
        """
        self.dataloader = dataloader
        self.img_size = img_size
        self.confthre = confthre
        self.nmsthre = nmsthre
        self.num_classes = num_classes
        self.testdev = testdev
        self.per_class_AP = per_class_AP
        self.per_class_AR = per_class_AR

    def evaluate(
        self, model, distributed=False, half=False, trt_file=None,
        decoder=None, test_size=None, return_outputs=False
    ):
        """
        COCO average precision (AP) Evaluation. Iterate inference on the test dataset
        and the results are evaluated by COCO API.

        NOTE: This function will change training mode to False, please save states if needed.

        Args:
            model : model to evaluate.

        Returns:
            ap50_95 (float) : COCO AP of IoU=50:95
            ap50 (float) : COCO AP of IoU=50
            summary (sr): summary info of evaluation.
        """
        # TODO half to amp_test
        tensor_type = torch.cuda.HalfTensor if half else torch.cuda.FloatTensor
        model = model.eval()
        if half:
            model = model.half()
        ids = []
        data_list = []
        output_data = defaultdict()
        progress_bar = tqdm if is_main_process() else iter

        inference_time = 0
        nms_time = 0
        n_samples = max(len(self.dataloader) - 1, 1)

        if trt_file is not None:
            from torch2trt import TRTModule

            model_trt = TRTModule()
            model_trt.load_state_dict(torch.load(trt_file))

            x = torch.ones(1, 3, test_size[0], test_size[1]).cuda()
            model(x)
            model = model_trt

        for cur_iter, (imgs, _, info_imgs, ids) in enumerate(
            progress_bar(self.dataloader)
        ):
            with torch.no_grad():
                imgs = imgs.type(tensor_type)

                # skip the last iters since batchsize might be not enough for batch inference
                is_time_record = cur_iter < len(self.dataloader) - 1
                if is_time_record:
                    start = time.time()

                outputs = model(imgs)
                if decoder is not None:
                    outputs = decoder(outputs, dtype=outputs.type())

                if is_time_record:
                    infer_end = time_synchronized()
                    inference_time += infer_end - start

                outputs = postprocess(
                    outputs, self.num_classes, self.confthre, self.nmsthre
                )
                if is_time_record:
                    nms_end = time_synchronized()
                    nms_time += nms_end - infer_end

            data_list_elem, image_wise_data = self.convert_to_coco_format(
                outputs, info_imgs, ids, return_outputs=True)
            data_list.extend(data_list_elem)
            output_data.update(image_wise_data)

        statistics = torch.cuda.FloatTensor([inference_time, nms_time, n_samples])
        if distributed:
            data_list = gather(data_list, dst=0)
            output_data = gather(output_data, dst=0)
            data_list = list(itertools.chain(*data_list))
            output_data = dict(ChainMap(*output_data))
            torch.distributed.reduce(statistics, dst=0)

        eval_results = self.evaluate_prediction(data_list, statistics)
        synchronize()

        if return_outputs:
            return eval_results, output_data
        return eval_results

    def convert_to_coco_format(self, outputs, info_imgs, ids, return_outputs=False):
        data_list = []
        image_wise_data = defaultdict(dict)
        for (output, img_h, img_w, img_id) in zip(
            outputs, info_imgs[0], info_imgs[1], ids
        ):
            if output is None:
                continue
            output = output.cpu()

            bboxes = output[:, 0:4]

            # preprocessing: resize
            scale = min(
                self.img_size[0] / float(img_h), self.img_size[1] / float(img_w)
            )
            bboxes /= scale
            cls = output[:, 6]
            scores = output[:, 4] * output[:, 5]

            image_wise_data.update({
                int(img_id): {
                    "bboxes": [box.numpy().tolist() for box in bboxes],
                    "scores": [score.numpy().item() for score in scores],
                    "categories": [
                        self.dataloader.dataset.class_ids[int(cls[ind])]
                        for ind in range(bboxes.shape[0])
                    ],
                }
            })

            bboxes = xyxy2xywh(bboxes)

            for ind in range(bboxes.shape[0]):
                label = self.dataloader.dataset.class_ids[int(cls[ind])]
                pred_data = {
                    "image_id": int(img_id),
                    "category_id": label,
                    "bbox": bboxes[ind].numpy().tolist(),
                    "score": scores[ind].numpy().item(),
                    "segmentation": [],
                }  # COCO json format
                data_list.append(pred_data)

        if return_outputs:
            return data_list, image_wise_data
        return data_list

    def evaluate_prediction(self, data_dict, statistics):
        if not is_main_process():
            return 0, 0, None

        logger.info("Evaluate in main process...")

        annType = ["segm", "bbox", "keypoints"]

        inference_time = statistics[0].item()
        nms_time = statistics[1].item()
        n_samples = statistics[2].item()

        a_infer_time = 1000 * inference_time / (n_samples * self.dataloader.batch_size)
        a_nms_time = 1000 * nms_time / (n_samples * self.dataloader.batch_size)

        time_info = ", ".join(
            [
                "Average {} time: {:.2f} ms".format(k, v)
                for k, v in zip(
                    ["forward", "NMS", "inference"],
                    [a_infer_time, a_nms_time, (a_infer_time + a_nms_time)],
                )
            ]
        )

        info = time_info + "\n"

        # Evaluate the Dt (detection) json comparing with the ground truth
        if len(data_dict) > 0:
            cocoGt = self.dataloader.dataset.coco
            # TODO: since pycocotools can't process dict in py36, write data to json file.
            if self.testdev:
                json.dump(data_dict, open("./yolox_testdev_2017.json", "w"))
                cocoDt = cocoGt.loadRes("./yolox_testdev_2017.json")
            else:
                _, tmp = tempfile.mkstemp()
                json.dump(data_dict, open(tmp, "w"))
                cocoDt = cocoGt.loadRes(tmp)
            try:
                from yolox.layers import COCOeval_opt as COCOeval
            except ImportError:
                from pycocotools.cocoeval import COCOeval

                logger.warning("Use standard COCOeval.")
            
           

            

            cocoEval = COCOeval(cocoGt, cocoDt, annType[1])
            cocoEval.evaluate()
            
            cocoEval.accumulate()
            redirect_string = io.StringIO()
            with contextlib.redirect_stdout(redirect_string):
                cocoEval.summarize()
            info += redirect_string.getvalue()
            cat_ids = list(cocoGt.cats.keys())
            
            confusion_matrix = ConfusionMatrix(nc=952)

            #file_name = []
            # for i in range(len(cocoGt.imgs)):#460张图
            #     file_name.append(cocoGt.loadImgs(i)[0]["file_name"])

            # df = (pd.DataFrame(file_name))
            # df.to_csv("file_name_test.csv", encoding='utf-8')

            stats = []
            with tqdm(total=len(cocoGt.imgs), desc="coco_eval") as p: 
                for i in range(len(cocoGt.imgs)):#460张图
                    # print(cocoGt.loadImgs(i)[0]["file_name"])
                    file_name = cocoGt.loadImgs(i)[0]["file_name"]
                    bbox_gt = np.array([y['bbox'] for y in cocoGt.imgToAnns[i]])
                    # class_gt = np.array([[y['category_id']-1] for y in coco_gt.imgToAnns[i]])
                    class_gt = np.array([[y['category_id']] for y in cocoGt.imgToAnns[i]])
                    labels = np.hstack((class_gt,bbox_gt))
                    
                    bbox_dt = np.array([y['bbox'] for y in cocoDt.imgToAnns[i]])
                    conf_dt = np.array([[y['score']] for y in cocoDt.imgToAnns[i]])
                    # class_dt = np.array([[y['category_id']-1] for y in coco_dt.imgToAnns[i]])
                    class_dt = np.array([[y['category_id']] for y in cocoDt.imgToAnns[i]])
                    predictions = np.hstack((np.hstack((bbox_dt,conf_dt)),class_dt))

                    p.update()
                    if len(predictions) > 0:
                        img_index = i
                        confusion_matrix.process_batch(predictions, labels, img_index, file_name)
                        #'''PR等曲线'''
                        detects = torch.tensor(xywh2xyxy(predictions))
                        labs = torch.tensor(np.hstack((labels[:, 0][:, None], xywh2xyxy(labels[:, 1:]))))
                        print("detects", detects.type("torch.LongTensor"))
                        print("labs", labs)
                        iouv = torch.linspace(0.5, 0.95, 10)  # iou vector for mAP@0.5:0.95
                        correct = process_batch(detects, labs, iouv)
                        tcls = labs[:, 0].tolist()  # target class
                        # print("---target class:", tcls)
                        stats.append((correct.cpu(), detects[:, 4].cpu(), detects[:, 5].cpu(), tcls))
                        p.update()
                    # with open('Typhoon_report.csv', 'w', encoding='UTF8') as f:
                    if annType == "segm":
                        f_name = f"segm_report.csv"
                    else:
                        f_name = f"test_bbox_report.csv"

                    # with open(f"{dataset_name}_report.csv", 'w', encoding='UTF8') as f:    
                    with open(f_name, 'w', encoding='UTF8') as f:
                        writer = csv.writer(f)

                        for content in confusion_matrix.csv:
                            writer.writerow(content)

                confusion_matrix.print()
                # plot_dir = "/home/smartcoop/test/data5-1/YOLOX_outputs"

                # names = {k: v for k, v in enumerate(['B01_C01_D10','B01_C01_D20','B01_C01_D30','B01_C01_D40','B01_C01_D50','B01_C01_D60','B01_C02_D10','B01_C02_D20','B01_C02_D30','B01_C02_D40','B01_C02_D50','B01_C02_D60','B01_C03_D10','B01_C03_D20','B01_C03_D30','B01_C03_D40','B01_C03_D50','B01_C03_D60','B01_C04_D10','B01_C04_D20','B01_C04_D30','B01_C04_D40','B01_C04_D50','B01_C04_D60','B01_C05_D10','B01_C05_D20','B01_C05_D30','B01_C05_D40','B01_C05_D50','B01_C05_D60','B01_C06_D10','B01_C06_D20','B01_C06_D30','B01_C06_D40','B01_C06_D50','B01_C06_D60','B01_C07_D10','B01_C07_D20','B01_C07_D30','B01_C07_D40','B01_C07_D50','B01_C07_D60','B01_C08_D10','B01_C08_D20','B01_C08_D30','B01_C08_D40','B01_C08_D50','B01_C08_D60','B01_C09_D10','B01_C09_D20','B01_C09_D30','B01_C09_D40','B01_C09_D50','B01_C09_D60','B01_C10_D10','B01_C10_D20','B01_C10_D30','B01_C10_D40','B01_C10_D50','B01_C10_D60','B01_C11_D10','B01_C11_D20','B01_C11_D30','B01_C11_D40','B01_C11_D50','B01_C11_D60','B01_C12_D10','B01_C12_D20','B01_C12_D30','B01_C12_D40','B01_C12_D50','B01_C12_D60','B01_C13_D10','B01_C13_D20','B01_C13_D30','B01_C13_D40','B01_C13_D50','B01_C13_D60','B01_C14_D10','B01_C14_D20','B01_C14_D30','B01_C14_D40','B01_C14_D50','B01_C14_D60','B01_C15_D10','B01_C15_D20','B01_C15_D30','B01_C15_D40','B01_C15_D50','B01_C15_D60','B01_C16_D10','B01_C16_D20','B01_C16_D30','B01_C16_D40','B01_C16_D50','B01_C16_D60','B01_C17_D10','B01_C17_D20','B01_C17_D30','B01_C17_D40','B01_C17_D50','B01_C17_D60','B01_C18_D10','B01_C18_D20','B01_C18_D30','B01_C18_D40','B01_C18_D50','B01_C18_D60','B01_C19_D10','B01_C19_D20','B01_C19_D30','B01_C19_D40','B01_C19_D50','B01_C19_D60','B01_C20_D10','B01_C20_D20','B01_C20_D30','B01_C20_D40','B01_C20_D50','B01_C20_D60','B01_C21_D10','B01_C21_D20','B01_C21_D30','B01_C21_D40','B01_C21_D50','B01_C21_D60','B01_C22_D10','B01_C22_D20','B01_C22_D30','B01_C22_D40','B01_C22_D50','B01_C22_D60','B01_C23_D10','B01_C23_D20','B01_C23_D30','B01_C23_D40','B01_C23_D50','B01_C23_D60','B01_C24_D10','B01_C24_D20','B01_C24_D30','B01_C24_D40','B01_C24_D50','B01_C24_D60','B01_C25_D10','B01_C25_D20','B01_C25_D30','B01_C25_D40','B01_C25_D50','B01_C25_D60','B02_C01_D10','B02_C01_D20','B02_C01_D30','B02_C01_D40','B02_C01_D50','B02_C01_D60','B02_C02_D10','B02_C02_D20','B02_C02_D30','B02_C02_D40','B02_C02_D50','B02_C02_D60','B02_C03_D10','B02_C03_D20','B02_C03_D30','B02_C03_D40','B02_C03_D50','B02_C03_D60','B02_C04_D10','B02_C04_D20','B02_C04_D30','B02_C04_D40','B02_C04_D50','B02_C04_D60','B02_C05_D10','B02_C05_D20','B02_C05_D30','B02_C05_D40','B02_C05_D50','B02_C05_D60','B02_C06_D10','B02_C06_D20','B02_C06_D30','B02_C06_D40','B02_C06_D50','B02_C06_D60','B02_C07_D10','B02_C07_D20','B02_C07_D30','B02_C07_D40','B02_C07_D50','B02_C07_D60','B02_C08_D10','B02_C08_D20','B02_C08_D30','B02_C08_D40','B02_C08_D50','B02_C08_D60','B02_C09_D10','B02_C09_D20','B02_C09_D30','B02_C09_D40','B02_C09_D50','B02_C09_D60','B02_C10_D10','B02_C10_D20','B02_C10_D30','B02_C10_D40','B02_C10_D50','B02_C10_D60','B02_C11_D10','B02_C11_D20','B02_C11_D30','B02_C11_D40','B02_C11_D50','B02_C11_D60','B02_C12_D10','B02_C12_D20','B02_C12_D30','B02_C12_D40','B02_C12_D50','B02_C12_D60','B02_C13_D10','B02_C13_D20','B02_C13_D30','B02_C13_D40','B02_C13_D50','B02_C13_D60','B03_C01_D10','B03_C01_D20','B03_C01_D30','B03_C01_D40','B03_C01_D50','B03_C01_D60','B03_C02_D10','B03_C02_D20','B03_C02_D30','B03_C02_D40','B03_C02_D50','B03_C02_D60','B03_C03_D10','B03_C03_D20','B03_C03_D30','B03_C03_D40','B03_C03_D50','B03_C03_D60','B03_C04_D10','B03_C04_D20','B03_C04_D30','B03_C04_D40','B03_C04_D50','B03_C04_D60','B03_C05_D10','B03_C05_D20','B03_C05_D30','B03_C05_D40','B03_C05_D50','B03_C05_D60','B03_C06_D10','B03_C06_D20','B03_C06_D30','B03_C06_D40','B03_C06_D50','B03_C06_D60','B03_C07_D10','B03_C07_D20','B03_C07_D30','B03_C07_D40','B03_C07_D50','B03_C07_D60','B03_C08_D10','B03_C08_D20','B03_C08_D30','B03_C08_D40','B03_C08_D50','B03_C08_D60','B03_C09_D10','B03_C09_D20','B03_C09_D30','B03_C09_D40','B03_C09_D50','B03_C09_D60','B04_C01_D10','B04_C01_D20','B04_C01_D30','B04_C01_D40','B04_C01_D50','B04_C01_D60','B04_C02_D10','B04_C02_D20','B04_C02_D30','B04_C02_D40','B04_C02_D50','B04_C02_D60','B04_C03_D10','B04_C03_D20','B04_C03_D30','B04_C03_D40','B04_C03_D50','B04_C03_D60','B04_C04_D10','B04_C04_D20','B04_C04_D30','B04_C04_D40','B04_C04_D50','B04_C04_D60','B04_C05_D10','B04_C05_D20','B04_C05_D30','B04_C05_D40','B04_C05_D50','B04_C05_D60','B04_C06_D10','B04_C06_D20','B04_C06_D30','B04_C06_D40','B04_C06_D50','B04_C06_D60','B04_C07_D10','B04_C07_D20','B04_C07_D30','B04_C07_D40','B04_C07_D50','B04_C07_D60','B05_C01_D10','B05_C01_D20','B05_C01_D30','B05_C01_D40','B05_C01_D50','B05_C01_D60','B05_C02_D10','B05_C02_D20','B05_C02_D30','B05_C02_D40','B05_C02_D50','B05_C02_D60','B05_C03_D10','B05_C03_D20','B05_C03_D30','B05_C03_D40','B05_C03_D50','B05_C03_D60','B05_C04_D10','B05_C04_D20','B05_C04_D30','B05_C04_D40','B05_C04_D50','B05_C04_D60','B05_C05_D10','B05_C05_D20','B05_C05_D30','B05_C05_D40','B05_C05_D50','B05_C05_D60','B06_C01_D10','B06_C01_D20','B06_C01_D30','B06_C01_D40','B06_C01_D50','B06_C01_D60','B06_C02_D10','B06_C02_D20','B06_C02_D30','B06_C02_D40','B06_C02_D50','B06_C02_D60','B06_C03_D10','B06_C03_D20','B06_C03_D30','B06_C03_D40','B06_C03_D50','B06_C03_D60','B06_C04_D10','B06_C04_D20','B06_C04_D30','B06_C04_D40','B06_C04_D50','B06_C04_D60','B06_C05_D10','B06_C05_D20','B06_C05_D30','B06_C05_D40','B06_C05_D50','B06_C05_D60','B06_C06_D10','B06_C06_D20','B06_C06_D30','B06_C06_D40','B06_C06_D50','B06_C06_D60','B06_C07_D10','B06_C07_D20','B06_C07_D30','B06_C07_D40','B06_C07_D50','B06_C07_D60','B06_C08_D10','B06_C08_D20','B06_C08_D30','B06_C08_D40','B06_C08_D50','B06_C08_D60','B06_C09_D10','B06_C09_D20','B06_C09_D30','B06_C09_D40','B06_C09_D50','B06_C09_D60','B06_C10_D10','B06_C10_D20','B06_C10_D30','B06_C10_D40','B06_C10_D50','B06_C10_D60','B07_C01_D10','B07_C01_D20','B07_C01_D30','B07_C01_D40','B07_C01_D50','B07_C01_D60','B07_C02_D10','B07_C02_D20','B07_C02_D30','B07_C02_D40','B07_C02_D50','B07_C02_D60','B07_C03_D10','B07_C03_D20','B07_C03_D30','B07_C03_D40','B07_C03_D50','B07_C03_D60','B07_C04_D10','B07_C04_D20','B07_C04_D30','B07_C04_D40','B07_C04_D50','B07_C04_D60','B07_C05_D10','B07_C05_D20','B07_C05_D30','B07_C05_D40','B07_C05_D50','B07_C05_D60','B07_C06_D10','B07_C06_D20','B07_C06_D30','B07_C06_D40','B07_C06_D50','B07_C06_D60','B07_C07_D10','B07_C07_D20','B07_C07_D30','B07_C07_D40','B07_C07_D50','B07_C07_D60','B07_C08_D10','B07_C08_D20','B07_C08_D30','B07_C08_D40','B07_C08_D50','B07_C08_D60','B07_C09_D10','B07_C09_D20','B07_C09_D30','B07_C09_D40','B07_C09_D50','B07_C09_D60','B08_C01_D10','B08_C01_D20','B08_C01_D30','B08_C01_D40','B08_C01_D50','B08_C01_D60','B08_C02_D10','B08_C02_D20','B08_C02_D30','B08_C02_D40','B08_C02_D50','B08_C02_D60','B08_C03_D10','B08_C03_D20','B08_C03_D30','B08_C03_D40','B08_C03_D50','B08_C03_D60','B08_C04_D10','B08_C04_D20','B08_C04_D30','B08_C04_D40','B08_C04_D50','B08_C04_D60','B08_C05_D10','B08_C05_D20','B08_C05_D30','B08_C05_D40','B08_C05_D50','B08_C05_D60','B08_C06_D10','B08_C06_D20','B08_C06_D30','B08_C06_D40','B08_C06_D50','B08_C06_D60','B08_C07_D10','B08_C07_D20','B08_C07_D30','B08_C07_D40','B08_C07_D50','B08_C07_D60','B09_C01_D10','B09_C01_D20','B09_C01_D30','B09_C01_D40','B09_C01_D50','B09_C01_D60','B09_C02_D10','B09_C02_D20','B09_C02_D30','B09_C02_D40','B09_C02_D50','B09_C02_D60','B09_C03_D10','B09_C03_D20','B09_C03_D30','B09_C03_D40','B09_C03_D50','B09_C03_D60','B09_C04_D10','B09_C04_D20','B09_C04_D30','B09_C04_D40','B09_C04_D50','B09_C04_D60','B09_C05_D10','B09_C05_D20','B09_C05_D30','B09_C05_D40','B09_C05_D50','B09_C05_D60','B09_C06_D10','B09_C06_D20','B09_C06_D30','B09_C06_D40','B09_C06_D50','B09_C06_D60','B09_C07_D10','B09_C07_D20','B09_C07_D30','B09_C07_D40','B09_C07_D50','B09_C07_D60','B09_C08_D10','B09_C08_D20','B09_C08_D30','B09_C08_D40','B09_C08_D50','B09_C08_D60','B09_C09_D10','B09_C09_D20','B09_C09_D30','B09_C09_D40','B09_C09_D50','B09_C09_D60','B10_C01_D10','B10_C01_D20','B10_C01_D30','B10_C01_D40','B10_C01_D50','B10_C01_D60','B10_C02_D10','B10_C02_D20','B10_C02_D30','B10_C02_D40','B10_C02_D50','B10_C02_D60','B10_C03_D10','B10_C03_D20','B10_C03_D30','B10_C03_D40','B10_C03_D50','B10_C03_D60','B10_C04_D10','B10_C04_D20','B10_C04_D30','B10_C04_D40','B10_C04_D50','B10_C04_D60','B10_C05_D10','B10_C05_D20','B10_C05_D30','B10_C05_D40','B10_C05_D50','B10_C05_D60','B10_C06_D10','B10_C06_D20','B10_C06_D30','B10_C06_D40','B10_C06_D50','B10_C06_D60','nan'])}
                # stats = [np.concatenate(x, 0) for x in zip(*stats)]
                # if len(stats) and stats[0].any():
                #     p, r, ap, f1, ap_class = ap_per_class(*stats, plot=True, save_dir=plot_dir, names=names)
                # confusion_matrix.plot(save_dir=plot_dir+"rec.png", names=['B01_C01_D10','B01_C01_D20','B01_C01_D30','B01_C01_D40','B01_C01_D50','B01_C01_D60','B01_C02_D10','B01_C02_D20','B01_C02_D30','B01_C02_D40','B01_C02_D50','B01_C02_D60','B01_C03_D10','B01_C03_D20','B01_C03_D30','B01_C03_D40','B01_C03_D50','B01_C03_D60','B01_C04_D10','B01_C04_D20','B01_C04_D30','B01_C04_D40','B01_C04_D50','B01_C04_D60','B01_C05_D10','B01_C05_D20','B01_C05_D30','B01_C05_D40','B01_C05_D50','B01_C05_D60','B01_C06_D10','B01_C06_D20','B01_C06_D30','B01_C06_D40','B01_C06_D50','B01_C06_D60','B01_C07_D10','B01_C07_D20','B01_C07_D30','B01_C07_D40','B01_C07_D50','B01_C07_D60','B01_C08_D10','B01_C08_D20','B01_C08_D30','B01_C08_D40','B01_C08_D50','B01_C08_D60','B01_C09_D10','B01_C09_D20','B01_C09_D30','B01_C09_D40','B01_C09_D50','B01_C09_D60','B01_C10_D10','B01_C10_D20','B01_C10_D30','B01_C10_D40','B01_C10_D50','B01_C10_D60','B01_C11_D10','B01_C11_D20','B01_C11_D30','B01_C11_D40','B01_C11_D50','B01_C11_D60','B01_C12_D10','B01_C12_D20','B01_C12_D30','B01_C12_D40','B01_C12_D50','B01_C12_D60','B01_C13_D10','B01_C13_D20','B01_C13_D30','B01_C13_D40','B01_C13_D50','B01_C13_D60','B01_C14_D10','B01_C14_D20','B01_C14_D30','B01_C14_D40','B01_C14_D50','B01_C14_D60','B01_C15_D10','B01_C15_D20','B01_C15_D30','B01_C15_D40','B01_C15_D50','B01_C15_D60','B01_C16_D10','B01_C16_D20','B01_C16_D30','B01_C16_D40','B01_C16_D50','B01_C16_D60','B01_C17_D10','B01_C17_D20','B01_C17_D30','B01_C17_D40','B01_C17_D50','B01_C17_D60','B01_C18_D10','B01_C18_D20','B01_C18_D30','B01_C18_D40','B01_C18_D50','B01_C18_D60','B01_C19_D10','B01_C19_D20','B01_C19_D30','B01_C19_D40','B01_C19_D50','B01_C19_D60','B01_C20_D10','B01_C20_D20','B01_C20_D30','B01_C20_D40','B01_C20_D50','B01_C20_D60','B01_C21_D10','B01_C21_D20','B01_C21_D30','B01_C21_D40','B01_C21_D50','B01_C21_D60','B01_C22_D10','B01_C22_D20','B01_C22_D30','B01_C22_D40','B01_C22_D50','B01_C22_D60','B01_C23_D10','B01_C23_D20','B01_C23_D30','B01_C23_D40','B01_C23_D50','B01_C23_D60','B01_C24_D10','B01_C24_D20','B01_C24_D30','B01_C24_D40','B01_C24_D50','B01_C24_D60','B01_C25_D10','B01_C25_D20','B01_C25_D30','B01_C25_D40','B01_C25_D50','B01_C25_D60','B02_C01_D10','B02_C01_D20','B02_C01_D30','B02_C01_D40','B02_C01_D50','B02_C01_D60','B02_C02_D10','B02_C02_D20','B02_C02_D30','B02_C02_D40','B02_C02_D50','B02_C02_D60','B02_C03_D10','B02_C03_D20','B02_C03_D30','B02_C03_D40','B02_C03_D50','B02_C03_D60','B02_C04_D10','B02_C04_D20','B02_C04_D30','B02_C04_D40','B02_C04_D50','B02_C04_D60','B02_C05_D10','B02_C05_D20','B02_C05_D30','B02_C05_D40','B02_C05_D50','B02_C05_D60','B02_C06_D10','B02_C06_D20','B02_C06_D30','B02_C06_D40','B02_C06_D50','B02_C06_D60','B02_C07_D10','B02_C07_D20','B02_C07_D30','B02_C07_D40','B02_C07_D50','B02_C07_D60','B02_C08_D10','B02_C08_D20','B02_C08_D30','B02_C08_D40','B02_C08_D50','B02_C08_D60','B02_C09_D10','B02_C09_D20','B02_C09_D30','B02_C09_D40','B02_C09_D50','B02_C09_D60','B02_C10_D10','B02_C10_D20','B02_C10_D30','B02_C10_D40','B02_C10_D50','B02_C10_D60','B02_C11_D10','B02_C11_D20','B02_C11_D30','B02_C11_D40','B02_C11_D50','B02_C11_D60','B02_C12_D10','B02_C12_D20','B02_C12_D30','B02_C12_D40','B02_C12_D50','B02_C12_D60','B02_C13_D10','B02_C13_D20','B02_C13_D30','B02_C13_D40','B02_C13_D50','B02_C13_D60','B03_C01_D10','B03_C01_D20','B03_C01_D30','B03_C01_D40','B03_C01_D50','B03_C01_D60','B03_C02_D10','B03_C02_D20','B03_C02_D30','B03_C02_D40','B03_C02_D50','B03_C02_D60','B03_C03_D10','B03_C03_D20','B03_C03_D30','B03_C03_D40','B03_C03_D50','B03_C03_D60','B03_C04_D10','B03_C04_D20','B03_C04_D30','B03_C04_D40','B03_C04_D50','B03_C04_D60','B03_C05_D10','B03_C05_D20','B03_C05_D30','B03_C05_D40','B03_C05_D50','B03_C05_D60','B03_C06_D10','B03_C06_D20','B03_C06_D30','B03_C06_D40','B03_C06_D50','B03_C06_D60','B03_C07_D10','B03_C07_D20','B03_C07_D30','B03_C07_D40','B03_C07_D50','B03_C07_D60','B03_C08_D10','B03_C08_D20','B03_C08_D30','B03_C08_D40','B03_C08_D50','B03_C08_D60','B03_C09_D10','B03_C09_D20','B03_C09_D30','B03_C09_D40','B03_C09_D50','B03_C09_D60','B04_C01_D10','B04_C01_D20','B04_C01_D30','B04_C01_D40','B04_C01_D50','B04_C01_D60','B04_C02_D10','B04_C02_D20','B04_C02_D30','B04_C02_D40','B04_C02_D50','B04_C02_D60','B04_C03_D10','B04_C03_D20','B04_C03_D30','B04_C03_D40','B04_C03_D50','B04_C03_D60','B04_C04_D10','B04_C04_D20','B04_C04_D30','B04_C04_D40','B04_C04_D50','B04_C04_D60','B04_C05_D10','B04_C05_D20','B04_C05_D30','B04_C05_D40','B04_C05_D50','B04_C05_D60','B04_C06_D10','B04_C06_D20','B04_C06_D30','B04_C06_D40','B04_C06_D50','B04_C06_D60','B04_C07_D10','B04_C07_D20','B04_C07_D30','B04_C07_D40','B04_C07_D50','B04_C07_D60','B05_C01_D10','B05_C01_D20','B05_C01_D30','B05_C01_D40','B05_C01_D50','B05_C01_D60','B05_C02_D10','B05_C02_D20','B05_C02_D30','B05_C02_D40','B05_C02_D50','B05_C02_D60','B05_C03_D10','B05_C03_D20','B05_C03_D30','B05_C03_D40','B05_C03_D50','B05_C03_D60','B05_C04_D10','B05_C04_D20','B05_C04_D30','B05_C04_D40','B05_C04_D50','B05_C04_D60','B05_C05_D10','B05_C05_D20','B05_C05_D30','B05_C05_D40','B05_C05_D50','B05_C05_D60','B06_C01_D10','B06_C01_D20','B06_C01_D30','B06_C01_D40','B06_C01_D50','B06_C01_D60','B06_C02_D10','B06_C02_D20','B06_C02_D30','B06_C02_D40','B06_C02_D50','B06_C02_D60','B06_C03_D10','B06_C03_D20','B06_C03_D30','B06_C03_D40','B06_C03_D50','B06_C03_D60','B06_C04_D10','B06_C04_D20','B06_C04_D30','B06_C04_D40','B06_C04_D50','B06_C04_D60','B06_C05_D10','B06_C05_D20','B06_C05_D30','B06_C05_D40','B06_C05_D50','B06_C05_D60','B06_C06_D10','B06_C06_D20','B06_C06_D30','B06_C06_D40','B06_C06_D50','B06_C06_D60','B06_C07_D10','B06_C07_D20','B06_C07_D30','B06_C07_D40','B06_C07_D50','B06_C07_D60','B06_C08_D10','B06_C08_D20','B06_C08_D30','B06_C08_D40','B06_C08_D50','B06_C08_D60','B06_C09_D10','B06_C09_D20','B06_C09_D30','B06_C09_D40','B06_C09_D50','B06_C09_D60','B06_C10_D10','B06_C10_D20','B06_C10_D30','B06_C10_D40','B06_C10_D50','B06_C10_D60','B07_C01_D10','B07_C01_D20','B07_C01_D30','B07_C01_D40','B07_C01_D50','B07_C01_D60','B07_C02_D10','B07_C02_D20','B07_C02_D30','B07_C02_D40','B07_C02_D50','B07_C02_D60','B07_C03_D10','B07_C03_D20','B07_C03_D30','B07_C03_D40','B07_C03_D50','B07_C03_D60','B07_C04_D10','B07_C04_D20','B07_C04_D30','B07_C04_D40','B07_C04_D50','B07_C04_D60','B07_C05_D10','B07_C05_D20','B07_C05_D30','B07_C05_D40','B07_C05_D50','B07_C05_D60','B07_C06_D10','B07_C06_D20','B07_C06_D30','B07_C06_D40','B07_C06_D50','B07_C06_D60','B07_C07_D10','B07_C07_D20','B07_C07_D30','B07_C07_D40','B07_C07_D50','B07_C07_D60','B07_C08_D10','B07_C08_D20','B07_C08_D30','B07_C08_D40','B07_C08_D50','B07_C08_D60','B07_C09_D10','B07_C09_D20','B07_C09_D30','B07_C09_D40','B07_C09_D50','B07_C09_D60','B08_C01_D10','B08_C01_D20','B08_C01_D30','B08_C01_D40','B08_C01_D50','B08_C01_D60','B08_C02_D10','B08_C02_D20','B08_C02_D30','B08_C02_D40','B08_C02_D50','B08_C02_D60','B08_C03_D10','B08_C03_D20','B08_C03_D30','B08_C03_D40','B08_C03_D50','B08_C03_D60','B08_C04_D10','B08_C04_D20','B08_C04_D30','B08_C04_D40','B08_C04_D50','B08_C04_D60','B08_C05_D10','B08_C05_D20','B08_C05_D30','B08_C05_D40','B08_C05_D50','B08_C05_D60','B08_C06_D10','B08_C06_D20','B08_C06_D30','B08_C06_D40','B08_C06_D50','B08_C06_D60','B08_C07_D10','B08_C07_D20','B08_C07_D30','B08_C07_D40','B08_C07_D50','B08_C07_D60','B09_C01_D10','B09_C01_D20','B09_C01_D30','B09_C01_D40','B09_C01_D50','B09_C01_D60','B09_C02_D10','B09_C02_D20','B09_C02_D30','B09_C02_D40','B09_C02_D50','B09_C02_D60','B09_C03_D10','B09_C03_D20','B09_C03_D30','B09_C03_D40','B09_C03_D50','B09_C03_D60','B09_C04_D10','B09_C04_D20','B09_C04_D30','B09_C04_D40','B09_C04_D50','B09_C04_D60','B09_C05_D10','B09_C05_D20','B09_C05_D30','B09_C05_D40','B09_C05_D50','B09_C05_D60','B09_C06_D10','B09_C06_D20','B09_C06_D30','B09_C06_D40','B09_C06_D50','B09_C06_D60','B09_C07_D10','B09_C07_D20','B09_C07_D30','B09_C07_D40','B09_C07_D50','B09_C07_D60','B09_C08_D10','B09_C08_D20','B09_C08_D30','B09_C08_D40','B09_C08_D50','B09_C08_D60','B09_C09_D10','B09_C09_D20','B09_C09_D30','B09_C09_D40','B09_C09_D50','B09_C09_D60','B10_C01_D10','B10_C01_D20','B10_C01_D30','B10_C01_D40','B10_C01_D50','B10_C01_D60','B10_C02_D10','B10_C02_D20','B10_C02_D30','B10_C02_D40','B10_C02_D50','B10_C02_D60','B10_C03_D10','B10_C03_D20','B10_C03_D30','B10_C03_D40','B10_C03_D50','B10_C03_D60','B10_C04_D10','B10_C04_D20','B10_C04_D30','B10_C04_D40','B10_C04_D50','B10_C04_D60','B10_C05_D10','B10_C05_D20','B10_C05_D30','B10_C05_D40','B10_C05_D50','B10_C05_D60','B10_C06_D10','B10_C06_D20','B10_C06_D30','B10_C06_D40','B10_C06_D50','B10_C06_D60','nan'], rec_or_pred=0)
                # confusion_matrix.plot(save_dir=plot_dir+"pred.png", names=['B01_C01_D10','B01_C01_D20','B01_C01_D30','B01_C01_D40','B01_C01_D50','B01_C01_D60','B01_C02_D10','B01_C02_D20','B01_C02_D30','B01_C02_D40','B01_C02_D50','B01_C02_D60','B01_C03_D10','B01_C03_D20','B01_C03_D30','B01_C03_D40','B01_C03_D50','B01_C03_D60','B01_C04_D10','B01_C04_D20','B01_C04_D30','B01_C04_D40','B01_C04_D50','B01_C04_D60','B01_C05_D10','B01_C05_D20','B01_C05_D30','B01_C05_D40','B01_C05_D50','B01_C05_D60','B01_C06_D10','B01_C06_D20','B01_C06_D30','B01_C06_D40','B01_C06_D50','B01_C06_D60','B01_C07_D10','B01_C07_D20','B01_C07_D30','B01_C07_D40','B01_C07_D50','B01_C07_D60','B01_C08_D10','B01_C08_D20','B01_C08_D30','B01_C08_D40','B01_C08_D50','B01_C08_D60','B01_C09_D10','B01_C09_D20','B01_C09_D30','B01_C09_D40','B01_C09_D50','B01_C09_D60','B01_C10_D10','B01_C10_D20','B01_C10_D30','B01_C10_D40','B01_C10_D50','B01_C10_D60','B01_C11_D10','B01_C11_D20','B01_C11_D30','B01_C11_D40','B01_C11_D50','B01_C11_D60','B01_C12_D10','B01_C12_D20','B01_C12_D30','B01_C12_D40','B01_C12_D50','B01_C12_D60','B01_C13_D10','B01_C13_D20','B01_C13_D30','B01_C13_D40','B01_C13_D50','B01_C13_D60','B01_C14_D10','B01_C14_D20','B01_C14_D30','B01_C14_D40','B01_C14_D50','B01_C14_D60','B01_C15_D10','B01_C15_D20','B01_C15_D30','B01_C15_D40','B01_C15_D50','B01_C15_D60','B01_C16_D10','B01_C16_D20','B01_C16_D30','B01_C16_D40','B01_C16_D50','B01_C16_D60','B01_C17_D10','B01_C17_D20','B01_C17_D30','B01_C17_D40','B01_C17_D50','B01_C17_D60','B01_C18_D10','B01_C18_D20','B01_C18_D30','B01_C18_D40','B01_C18_D50','B01_C18_D60','B01_C19_D10','B01_C19_D20','B01_C19_D30','B01_C19_D40','B01_C19_D50','B01_C19_D60','B01_C20_D10','B01_C20_D20','B01_C20_D30','B01_C20_D40','B01_C20_D50','B01_C20_D60','B01_C21_D10','B01_C21_D20','B01_C21_D30','B01_C21_D40','B01_C21_D50','B01_C21_D60','B01_C22_D10','B01_C22_D20','B01_C22_D30','B01_C22_D40','B01_C22_D50','B01_C22_D60','B01_C23_D10','B01_C23_D20','B01_C23_D30','B01_C23_D40','B01_C23_D50','B01_C23_D60','B01_C24_D10','B01_C24_D20','B01_C24_D30','B01_C24_D40','B01_C24_D50','B01_C24_D60','B01_C25_D10','B01_C25_D20','B01_C25_D30','B01_C25_D40','B01_C25_D50','B01_C25_D60','B02_C01_D10','B02_C01_D20','B02_C01_D30','B02_C01_D40','B02_C01_D50','B02_C01_D60','B02_C02_D10','B02_C02_D20','B02_C02_D30','B02_C02_D40','B02_C02_D50','B02_C02_D60','B02_C03_D10','B02_C03_D20','B02_C03_D30','B02_C03_D40','B02_C03_D50','B02_C03_D60','B02_C04_D10','B02_C04_D20','B02_C04_D30','B02_C04_D40','B02_C04_D50','B02_C04_D60','B02_C05_D10','B02_C05_D20','B02_C05_D30','B02_C05_D40','B02_C05_D50','B02_C05_D60','B02_C06_D10','B02_C06_D20','B02_C06_D30','B02_C06_D40','B02_C06_D50','B02_C06_D60','B02_C07_D10','B02_C07_D20','B02_C07_D30','B02_C07_D40','B02_C07_D50','B02_C07_D60','B02_C08_D10','B02_C08_D20','B02_C08_D30','B02_C08_D40','B02_C08_D50','B02_C08_D60','B02_C09_D10','B02_C09_D20','B02_C09_D30','B02_C09_D40','B02_C09_D50','B02_C09_D60','B02_C10_D10','B02_C10_D20','B02_C10_D30','B02_C10_D40','B02_C10_D50','B02_C10_D60','B02_C11_D10','B02_C11_D20','B02_C11_D30','B02_C11_D40','B02_C11_D50','B02_C11_D60','B02_C12_D10','B02_C12_D20','B02_C12_D30','B02_C12_D40','B02_C12_D50','B02_C12_D60','B02_C13_D10','B02_C13_D20','B02_C13_D30','B02_C13_D40','B02_C13_D50','B02_C13_D60','B03_C01_D10','B03_C01_D20','B03_C01_D30','B03_C01_D40','B03_C01_D50','B03_C01_D60','B03_C02_D10','B03_C02_D20','B03_C02_D30','B03_C02_D40','B03_C02_D50','B03_C02_D60','B03_C03_D10','B03_C03_D20','B03_C03_D30','B03_C03_D40','B03_C03_D50','B03_C03_D60','B03_C04_D10','B03_C04_D20','B03_C04_D30','B03_C04_D40','B03_C04_D50','B03_C04_D60','B03_C05_D10','B03_C05_D20','B03_C05_D30','B03_C05_D40','B03_C05_D50','B03_C05_D60','B03_C06_D10','B03_C06_D20','B03_C06_D30','B03_C06_D40','B03_C06_D50','B03_C06_D60','B03_C07_D10','B03_C07_D20','B03_C07_D30','B03_C07_D40','B03_C07_D50','B03_C07_D60','B03_C08_D10','B03_C08_D20','B03_C08_D30','B03_C08_D40','B03_C08_D50','B03_C08_D60','B03_C09_D10','B03_C09_D20','B03_C09_D30','B03_C09_D40','B03_C09_D50','B03_C09_D60','B04_C01_D10','B04_C01_D20','B04_C01_D30','B04_C01_D40','B04_C01_D50','B04_C01_D60','B04_C02_D10','B04_C02_D20','B04_C02_D30','B04_C02_D40','B04_C02_D50','B04_C02_D60','B04_C03_D10','B04_C03_D20','B04_C03_D30','B04_C03_D40','B04_C03_D50','B04_C03_D60','B04_C04_D10','B04_C04_D20','B04_C04_D30','B04_C04_D40','B04_C04_D50','B04_C04_D60','B04_C05_D10','B04_C05_D20','B04_C05_D30','B04_C05_D40','B04_C05_D50','B04_C05_D60','B04_C06_D10','B04_C06_D20','B04_C06_D30','B04_C06_D40','B04_C06_D50','B04_C06_D60','B04_C07_D10','B04_C07_D20','B04_C07_D30','B04_C07_D40','B04_C07_D50','B04_C07_D60','B05_C01_D10','B05_C01_D20','B05_C01_D30','B05_C01_D40','B05_C01_D50','B05_C01_D60','B05_C02_D10','B05_C02_D20','B05_C02_D30','B05_C02_D40','B05_C02_D50','B05_C02_D60','B05_C03_D10','B05_C03_D20','B05_C03_D30','B05_C03_D40','B05_C03_D50','B05_C03_D60','B05_C04_D10','B05_C04_D20','B05_C04_D30','B05_C04_D40','B05_C04_D50','B05_C04_D60','B05_C05_D10','B05_C05_D20','B05_C05_D30','B05_C05_D40','B05_C05_D50','B05_C05_D60','B06_C01_D10','B06_C01_D20','B06_C01_D30','B06_C01_D40','B06_C01_D50','B06_C01_D60','B06_C02_D10','B06_C02_D20','B06_C02_D30','B06_C02_D40','B06_C02_D50','B06_C02_D60','B06_C03_D10','B06_C03_D20','B06_C03_D30','B06_C03_D40','B06_C03_D50','B06_C03_D60','B06_C04_D10','B06_C04_D20','B06_C04_D30','B06_C04_D40','B06_C04_D50','B06_C04_D60','B06_C05_D10','B06_C05_D20','B06_C05_D30','B06_C05_D40','B06_C05_D50','B06_C05_D60','B06_C06_D10','B06_C06_D20','B06_C06_D30','B06_C06_D40','B06_C06_D50','B06_C06_D60','B06_C07_D10','B06_C07_D20','B06_C07_D30','B06_C07_D40','B06_C07_D50','B06_C07_D60','B06_C08_D10','B06_C08_D20','B06_C08_D30','B06_C08_D40','B06_C08_D50','B06_C08_D60','B06_C09_D10','B06_C09_D20','B06_C09_D30','B06_C09_D40','B06_C09_D50','B06_C09_D60','B06_C10_D10','B06_C10_D20','B06_C10_D30','B06_C10_D40','B06_C10_D50','B06_C10_D60','B07_C01_D10','B07_C01_D20','B07_C01_D30','B07_C01_D40','B07_C01_D50','B07_C01_D60','B07_C02_D10','B07_C02_D20','B07_C02_D30','B07_C02_D40','B07_C02_D50','B07_C02_D60','B07_C03_D10','B07_C03_D20','B07_C03_D30','B07_C03_D40','B07_C03_D50','B07_C03_D60','B07_C04_D10','B07_C04_D20','B07_C04_D30','B07_C04_D40','B07_C04_D50','B07_C04_D60','B07_C05_D10','B07_C05_D20','B07_C05_D30','B07_C05_D40','B07_C05_D50','B07_C05_D60','B07_C06_D10','B07_C06_D20','B07_C06_D30','B07_C06_D40','B07_C06_D50','B07_C06_D60','B07_C07_D10','B07_C07_D20','B07_C07_D30','B07_C07_D40','B07_C07_D50','B07_C07_D60','B07_C08_D10','B07_C08_D20','B07_C08_D30','B07_C08_D40','B07_C08_D50','B07_C08_D60','B07_C09_D10','B07_C09_D20','B07_C09_D30','B07_C09_D40','B07_C09_D50','B07_C09_D60','B08_C01_D10','B08_C01_D20','B08_C01_D30','B08_C01_D40','B08_C01_D50','B08_C01_D60','B08_C02_D10','B08_C02_D20','B08_C02_D30','B08_C02_D40','B08_C02_D50','B08_C02_D60','B08_C03_D10','B08_C03_D20','B08_C03_D30','B08_C03_D40','B08_C03_D50','B08_C03_D60','B08_C04_D10','B08_C04_D20','B08_C04_D30','B08_C04_D40','B08_C04_D50','B08_C04_D60','B08_C05_D10','B08_C05_D20','B08_C05_D30','B08_C05_D40','B08_C05_D50','B08_C05_D60','B08_C06_D10','B08_C06_D20','B08_C06_D30','B08_C06_D40','B08_C06_D50','B08_C06_D60','B08_C07_D10','B08_C07_D20','B08_C07_D30','B08_C07_D40','B08_C07_D50','B08_C07_D60','B09_C01_D10','B09_C01_D20','B09_C01_D30','B09_C01_D40','B09_C01_D50','B09_C01_D60','B09_C02_D10','B09_C02_D20','B09_C02_D30','B09_C02_D40','B09_C02_D50','B09_C02_D60','B09_C03_D10','B09_C03_D20','B09_C03_D30','B09_C03_D40','B09_C03_D50','B09_C03_D60','B09_C04_D10','B09_C04_D20','B09_C04_D30','B09_C04_D40','B09_C04_D50','B09_C04_D60','B09_C05_D10','B09_C05_D20','B09_C05_D30','B09_C05_D40','B09_C05_D50','B09_C05_D60','B09_C06_D10','B09_C06_D20','B09_C06_D30','B09_C06_D40','B09_C06_D50','B09_C06_D60','B09_C07_D10','B09_C07_D20','B09_C07_D30','B09_C07_D40','B09_C07_D50','B09_C07_D60','B09_C08_D10','B09_C08_D20','B09_C08_D30','B09_C08_D40','B09_C08_D50','B09_C08_D60','B09_C09_D10','B09_C09_D20','B09_C09_D30','B09_C09_D40','B09_C09_D50','B09_C09_D60','B10_C01_D10','B10_C01_D20','B10_C01_D30','B10_C01_D40','B10_C01_D50','B10_C01_D60','B10_C02_D10','B10_C02_D20','B10_C02_D30','B10_C02_D40','B10_C02_D50','B10_C02_D60','B10_C03_D10','B10_C03_D20','B10_C03_D30','B10_C03_D40','B10_C03_D50','B10_C03_D60','B10_C04_D10','B10_C04_D20','B10_C04_D30','B10_C04_D40','B10_C04_D50','B10_C04_D60','B10_C05_D10','B10_C05_D20','B10_C05_D30','B10_C05_D40','B10_C05_D50','B10_C05_D60','B10_C06_D10','B10_C06_D20','B10_C06_D30','B10_C06_D40','B10_C06_D50','B10_C06_D60','nan'], rec_or_pred=1)

                
            # f = open('filename.csv', 'w', newline='') 
            # writer = csv.writer(f)
            # writer.writerow(file_name)
            # f.close()
            #change
            cat_names = []
            for catId in cat_ids:
            	catname = cocoGt.cats[catId]["name"]
            	catobj = cocoGt.cats[catId]["object"]
            	catlevel = cocoGt.cats[catId]["level2"]
            	cl = catlevel + '_' + catobj + '_' + catname
            	cat_names.append(cl)
            #cat_names = [cocoGt.cats[catId]['name'] for catId in sorted(cat_ids)]
            if self.per_class_AP:
                AP_table = per_class_AP_table(cocoEval, class_names=cat_names)
                info += "per class AP:\n" + AP_table + "\n"
            if self.per_class_AR:
                AR_table = per_class_AR_table(cocoEval, class_names=cat_names)
                info += "per class AR:\n" + AR_table + "\n"
            return cocoEval.stats[0], cocoEval.stats[1], info
        else:
            return 0, 0, info
